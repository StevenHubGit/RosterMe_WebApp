﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RosterMe.Classes
{
    public class EmailCredentials
    {
       public string email = "poojajadhav315@gmail.com";
       public string password = "poojapari14";
    }
}
